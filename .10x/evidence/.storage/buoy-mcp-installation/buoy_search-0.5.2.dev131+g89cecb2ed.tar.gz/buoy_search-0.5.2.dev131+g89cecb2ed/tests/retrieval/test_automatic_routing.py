from __future__ import annotations

from contextlib import redirect_stderr, redirect_stdout
from dataclasses import replace
from io import StringIO
import hashlib
import json
import math
import os
from pathlib import Path
import unittest
from unittest.mock import Mock, patch

from buoy_search.catalog.local import (
    ROUTING_DIMENSIONS,
    ROUTING_MODEL,
    ROUTING_QUERY_PREFIX,
    CardFields,
    NamespaceCard,
    prepare_card,
    routing_source_passage_text,
    vector_hash,
)
from buoy_search.cli.main import main
from buoy_search.retrieval.evidence import EvidenceCalibrationError
from buoy_search.retrieval.retriever import CalibratedEvidenceAssessor, EvidenceRouteContext
from buoy_search.catalog.remote import (
    CompatibilityContract,
    REMOTE_CATALOG_NAMESPACE,
    classify_remote_catalog,
)
from buoy_search.retrieval.routing import (
    AutomaticRoutingError,
    hybrid_route,
    named_route,
    prototype_route,
    prototype_route_scores,
    semantic_route,
)
from buoy_search.evals import routing_quality as routing_quality_module
from buoy_search.evals.routing_quality import (
    ROUTING_ACTIVE_ANCHOR_NAMESPACES,
    ROUTING_ACTIVE_CATALOG_PROJECTION_SHA256,
    ROUTING_ACTIVE_MARGIN_FLOOR,
    ROUTING_ACTIVE_SCORE_FLOOR,
    RoutingConfidenceCatalogState,
    load_routing_confidence_calibration,
)
from tests.retrieval.routing_confidence_fixtures import load_collect_routing_confidence_fixture


def unit_vector(index: int = 0) -> list[float]:
    vector = [0.0] * ROUTING_DIMENSIONS
    vector[index] = 1.0
    return vector


def cosine_vector(score: float) -> list[float]:
    vector = [0.0] * ROUTING_DIMENSIONS
    vector[0] = score
    vector[1] = math.sqrt(1.0 - score * score)
    return vector


def active_routing_calibration():  # noqa: ANN201 - focused fixture helper.
    return load_routing_confidence_calibration()


def anchored_routing_calibration():  # noqa: ANN201 - focused fixture helper.
    return active_routing_calibration()


class FixedEmbedder:
    def __init__(self, vector: list[float] | None = None) -> None:
        self.vector = list(vector or unit_vector())
        self.calls: list[list[str]] = []

    def encode(self, texts):  # noqa: ANN001 - protocol test double.
        self.calls.append(list(texts))
        return [list(self.vector) for _ in texts]


class SequenceEmbedder:
    def __init__(self, vectors: list[list[float]]) -> None:
        self.vectors = [list(vector) for vector in vectors]
        self.calls: list[list[str]] = []

    def encode(self, texts):  # noqa: ANN001 - protocol test double.
        values = list(texts)
        self.calls.append(values)
        if len(values) != len(self.vectors):
            raise AssertionError(
                f"expected {len(self.vectors)} passages, received {len(values)}"
            )
        return [list(vector) for vector in self.vectors]


class FixedReranker:
    def __init__(self, scores: list[float]) -> None:
        self.scores = list(scores)
        self.calls: list[tuple[str, list[str]]] = []

    def score(self, query: str, passages):  # noqa: ANN001 - protocol test double.
        values = list(passages)
        self.calls.append((query, values))
        if len(values) != len(self.scores):
            raise AssertionError(
                f"expected {len(self.scores)} passages, received {len(values)}"
            )
        return list(self.scores)


def make_card(
    namespace: str,
    *,
    title: str | None = None,
    summary: str = "Routing test source.",
    aliases: list[str] | None = None,
    vector: list[float] | None = None,
    enabled: bool = True,
    embedding_precision: str = "float32",
    routing_examples: list[str] | None = None,
    routing_passages: list[str] | None = None,
    passage_vectors: list[list[float]] | None = None,
) -> NamespaceCard:
    return prepare_card(
        CardFields(
            namespace=namespace,
            enabled=enabled,
            source_kind="website",
            source_uri=f"https://{namespace}.example/docs",
            site_id=f"site-{namespace}",
            title=title or namespace,
            summary=summary,
            aliases=list(aliases or []),
            tags=["website"],
            semantic_origin="manual",
            region="gcp-us-central1",
            embedding_model=ROUTING_MODEL,
            embedding_precision=embedding_precision,
            plan_schema_version=2,
            ranking_mode="page",
            ranking_profile="none",
            ranking_pool=20,
            ranking_aggregation="max",
            routing_examples=list(routing_examples or []),
            routing_passages=list(routing_passages or []),
        ),
        embedder=(
            SequenceEmbedder(passage_vectors)
            if passage_vectors is not None
            else FixedEmbedder(vector)
        ),
        now="2026-08-13T12:00:00+00:00",
    )


def snapshot(
    cards: list[NamespaceCard],
    *,
    extra_live: tuple[str, ...] = (),
):
    live = [REMOTE_CATALOG_NAMESPACE, *(card.namespace for card in cards), *extra_live]
    return classify_remote_catalog(
        live_namespace_ids=live,
        cards=cards,
        compatibility=CompatibilityContract(
            region="gcp-us-central1",
            embedding_model=ROUTING_MODEL,
            embedding_precision="float32",
        ),
    )


def run_cli(args: list[str], *, env: dict[str, str] | None = None) -> tuple[int, str, str]:
    stdout = StringIO()
    stderr = StringIO()
    with patch.object(os, "environ", env or {}), redirect_stdout(stdout), redirect_stderr(stderr):
        result = main(args)
    return result, stdout.getvalue(), stderr.getvalue()


class RoutingAlgorithmTests(unittest.TestCase):
    def test_title_and_alias_matching_never_uses_summary_or_tags_for_shortcut(self) -> None:
        cards = [
            make_card("dagster", title="Dagster", aliases=["dagster.io"]),
            make_card("other", title="Other", summary="Dagster website"),
        ]
        self.assertEqual(
            [card.namespace for card in named_route("How does dagster.io work?", cards)],
            ["dagster"],
        )
        self.assertEqual(named_route("website", cards), [])

    def test_simple_domain_title_matches_its_product_name_without_card_mutation(self) -> None:
        cards = [
            make_card("tpuf", title="turbopuffer.com", aliases=[]),
            make_card("other", title="Other"),
        ]
        self.assertEqual(
            [card.namespace for card in named_route("How does Turbopuffer work?", cards)],
            ["tpuf"],
        )
        self.assertEqual(
            [card.namespace for card in named_route("Read turbopuffer.com docs", cards)],
            ["tpuf"],
        )

    def test_unique_named_route_selects_one_with_bounded_fallback_candidates(self) -> None:
        cards = [
            make_card("dagster", title="Dagster", vector=cosine_vector(0.2)),
            make_card("tpuf", title="Turbopuffer", vector=cosine_vector(0.9)),
            make_card("thistle", title="Thistle", vector=cosine_vector(0.5)),
        ]
        selection = hybrid_route(
            "How does Dagster model assets?",
            cards,
            embedder=FixedEmbedder(),
            route_top_k=3,
        )
        self.assertEqual(selection.initial_fanout, 1)
        self.assertEqual(selection.selection_reason, "unique_title_or_alias")
        self.assertEqual(selection.selected_cards[0].namespace, "dagster")
        self.assertEqual(len(selection.selected_cards), 3)
        self.assertTrue(selection.entries[0].exact_name_match)

    def test_two_named_corpora_select_exactly_those_two(self) -> None:
        cards = [
            make_card("dagster", title="Dagster"),
            make_card("tpuf", title="Turbopuffer"),
            make_card("thistle", title="Thistle"),
        ]
        selection = hybrid_route(
            "Compare Turbopuffer and Dagster",
            cards,
            embedder=FixedEmbedder(),
            route_top_k=3,
        )
        self.assertEqual(
            {card.namespace for card in selection.selected_cards},
            {"dagster", "tpuf"},
        )
        self.assertEqual(selection.initial_fanout, 2)
        self.assertEqual(selection.selection_reason, "multiple_named_corpora")

    def test_three_named_corpora_select_exactly_those_three(self) -> None:
        cards = [
            make_card("dagster", title="Dagster"),
            make_card("tpuf", title="Turbopuffer"),
            make_card("thistle", title="Thistle"),
            make_card("oscilar", title="Oscilar"),
        ]
        selection = hybrid_route(
            "Compare Turbopuffer, Dagster, and Thistle",
            cards,
            embedder=FixedEmbedder(),
            route_top_k=3,
        )
        self.assertEqual(
            {card.namespace for card in selection.selected_cards},
            {"dagster", "tpuf", "thistle"},
        )
        self.assertEqual(selection.initial_fanout, 3)

    def test_more_than_three_named_corpora_fail_closed(self) -> None:
        cards = [
            make_card("dagster", title="Dagster"),
            make_card("tpuf", title="Turbopuffer"),
            make_card("thistle", title="Thistle"),
            make_card("oscilar", title="Oscilar"),
        ]
        with self.assertRaisesRegex(
            AutomaticRoutingError, "query names 4 corpora"
        ):
            hybrid_route(
                "Compare Turbopuffer, Dagster, Thistle, and Oscilar",
                cards,
                embedder=FixedEmbedder(),
                route_top_k=3,
            )

    def test_semantic_threshold_and_margin_choose_one_or_three(self) -> None:
        confident_cards = [
            make_card("first", vector=cosine_vector(0.80)),
            make_card("second", vector=cosine_vector(0.70)),
            make_card("third", vector=cosine_vector(0.20)),
        ]
        confident = hybrid_route(
            "descriptor free question",
            confident_cards,
            embedder=FixedEmbedder(),
            route_top_k=3,
        )
        self.assertTrue(confident.high_confidence)
        self.assertEqual(confident.initial_fanout, 1)
        self.assertEqual(confident.selection_reason, "high_confidence_semantic")

        ambiguous_cards = [
            make_card("first", vector=cosine_vector(0.80)),
            make_card("second", vector=cosine_vector(0.77)),
            make_card("third", vector=cosine_vector(0.20)),
        ]
        ambiguous = hybrid_route(
            "descriptor free question",
            ambiguous_cards,
            embedder=FixedEmbedder(),
            route_top_k=3,
        )
        self.assertFalse(ambiguous.high_confidence)
        self.assertEqual(ambiguous.initial_fanout, 3)
        self.assertEqual(ambiguous.selection_reason, "ambiguous_semantic")

    def test_semantic_query_is_prefixed_and_invalid_vectors_fail(self) -> None:
        embedder = FixedEmbedder()
        card = make_card("one")
        semantic_route(" routing question ", [card], embedder=embedder)
        self.assertEqual(embedder.calls, [[f"{ROUTING_QUERY_PREFIX}routing question"]])
        with self.assertRaisesRegex(AutomaticRoutingError, "exactly 384"):
            semantic_route("query", [card], embedder=FixedEmbedder([1.0]))

    def test_prototype_route_uses_one_embedding_and_max_example_score(self) -> None:
        cards = [
            make_card(
                "alpha",
                vector=cosine_vector(0.9),
                routing_examples=["Which API returns namespace schema metadata?"],
            ),
            make_card("beta", vector=cosine_vector(0.8)),
        ]
        embedder = FixedEmbedder()
        reranker = FixedReranker([-5.0, 8.0, 7.0])
        collect = prototype_route(
            "How can I inspect schema metadata?",
            cards,
            calibration=load_collect_routing_confidence_fixture(),
            embedder=embedder,
            reranker_loader=lambda: reranker,
            route_top_k=3,
        )
        self.assertEqual(len(embedder.calls), 1)
        self.assertEqual(
            embedder.calls,
            [[f"{ROUTING_QUERY_PREFIX}How can I inspect schema metadata?"]],
        )
        self.assertEqual(len(reranker.calls), 1)
        self.assertEqual([card.namespace for card in collect.selected_cards], ["alpha", "beta"])
        self.assertEqual(collect.initial_fanout, 2)
        self.assertFalse(collect.high_confidence)
        self.assertEqual(collect.entries[0].winning_prototype_kind, "example")
        self.assertEqual(collect.entries[0].winning_prototype_index, 0)
        self.assertNotIn(
            "Which API returns",
            json.dumps(collect.to_dict()),
        )
        self.assertFalse(collect.to_dict()["active"])
        self.assertEqual(
            collect.to_dict()["confidence_artifact"]["mode"], "collect"
        )
        self.assertEqual(collect.to_dict()["routing_confidence_mode"], "provisional")
        self.assertFalse(collect.to_dict()["confidence_threshold_applied"])
        self.assertEqual(collect.to_dict()["provisional_namespace_count"], 2)

    def test_source_passage_participates_in_reranking_without_leaking_content(
        self,
    ) -> None:
        source_passage = (
            "Section: Schema inspection\n"
            "Use the namespace schema endpoint to inspect attribute types."
        )
        cards = [
            make_card(
                "alpha",
                vector=cosine_vector(0.9),
                routing_passages=[source_passage],
            ),
            make_card("beta", vector=cosine_vector(0.8)),
        ]
        reranker = FixedReranker([-5.0, 8.0, 7.0])

        selection = prototype_route(
            "How can I inspect schema metadata?",
            cards,
            calibration=load_collect_routing_confidence_fixture(),
            embedder=FixedEmbedder(),
            reranker_loader=lambda: reranker,
            route_top_k=3,
        )

        self.assertEqual(
            reranker.calls[0][1][1],
            routing_source_passage_text(
                title=cards[0].title,
                summary=cards[0].summary,
                passage=source_passage,
            ),
        )
        self.assertEqual(selection.entries[0].winning_prototype_kind, "source")
        self.assertEqual(selection.entries[0].winning_prototype_index, 0)
        self.assertNotIn("namespace schema endpoint", json.dumps(selection.to_dict()))

    def test_source_passage_budget_and_projection_fail_before_model_work(self) -> None:
        valid = make_card(
            "alpha",
            routing_examples=[f"Manual example {index}" for index in range(8)],
        )
        over_budget = replace(
            valid,
            routing_passages=["Section: Extra\nGenerated evidence."],
        )
        embedder = FixedEmbedder()
        with self.assertRaisesRegex(AutomaticRoutingError, "at most 8"):
            prototype_route_scores(
                "question",
                [over_budget],
                embedder=embedder,
                reranker=FixedReranker([]),
            )
        self.assertEqual(embedder.calls, [])

        passage_card = make_card(
            "alpha",
            routing_passages=["Section: API\nGenerated evidence."],
        )
        stale = replace(passage_card, routing_prototype_hash="0" * 64)
        with self.assertRaisesRegex(AutomaticRoutingError, "projection is stale"):
            prototype_route_scores(
                "question",
                [stale],
                embedder=embedder,
                reranker=FixedReranker([]),
            )
        self.assertEqual(embedder.calls, [])

    def test_active_prototype_route_applies_both_inclusive_floors(self) -> None:
        cards = [make_card("alpha"), make_card("beta"), make_card("gamma")]
        calibration = active_routing_calibration()
        cases = (
            (
                "exact score floor",
                [
                    ROUTING_ACTIVE_SCORE_FLOOR,
                    ROUTING_ACTIVE_SCORE_FLOOR
                    - ROUTING_ACTIVE_MARGIN_FLOOR
                    - 0.5,
                    ROUTING_ACTIVE_SCORE_FLOOR - 3.0,
                ],
                True,
            ),
            (
                "exact margin floor",
                [0.0, -ROUTING_ACTIVE_MARGIN_FLOOR, -3.0],
                True,
            ),
            (
                "score below floor",
                [
                    ROUTING_ACTIVE_SCORE_FLOOR - 0.000001,
                    ROUTING_ACTIVE_SCORE_FLOOR - 2.0,
                    ROUTING_ACTIVE_SCORE_FLOOR - 3.0,
                ],
                False,
            ),
            (
                "margin below floor",
                [0.0, -ROUTING_ACTIVE_MARGIN_FLOOR + 0.000001, -3.0],
                False,
            ),
        )
        for label, scores, expected_confident in cases:
            with self.subTest(label=label), patch(
                "buoy_search.retrieval.routing.validate_routing_confidence_catalog",
                return_value=ROUTING_ACTIVE_CATALOG_PROJECTION_SHA256,
            ):
                selection = prototype_route(
                    "descriptor-free routing question",
                    cards,
                    calibration=calibration,
                    embedder=FixedEmbedder(),
                    reranker_loader=lambda scores=scores: FixedReranker(scores),
                    route_top_k=3,
                )

            self.assertEqual(selection.high_confidence, expected_confident)
            self.assertEqual(
                selection.selection_reason,
                (
                    "high_confidence_prototype"
                    if expected_confident
                    else "ambiguous_prototype"
                ),
            )
            self.assertEqual(selection.initial_fanout, 1 if expected_confident else 3)
            self.assertEqual(len(selection.selected_cards), 3)

    def test_active_single_eligible_card_has_no_confidence_margin(self) -> None:
        reranker = FixedReranker([0.0])
        with patch(
            "buoy_search.retrieval.routing.validate_routing_confidence_catalog",
            return_value=ROUTING_ACTIVE_CATALOG_PROJECTION_SHA256,
        ):
            selection = prototype_route(
                "descriptor-free routing question",
                [make_card("only")],
                calibration=active_routing_calibration(),
                embedder=FixedEmbedder(),
                reranker_loader=lambda: reranker,
                route_top_k=3,
            )

        self.assertFalse(selection.high_confidence)
        self.assertIsNone(selection.reranker_margin)
        self.assertEqual(selection.selection_reason, "ambiguous_prototype")
        self.assertEqual(selection.initial_fanout, 1)

    def test_active_prototype_output_is_truthful_and_content_free(self) -> None:
        cards = [make_card("alpha"), make_card("beta"), make_card("gamma")]
        with patch(
            "buoy_search.retrieval.routing.validate_routing_confidence_catalog",
            return_value=ROUTING_ACTIVE_CATALOG_PROJECTION_SHA256,
        ):
            selection = prototype_route(
                "descriptor-free routing question",
                cards,
                calibration=active_routing_calibration(),
                embedder=FixedEmbedder(),
                reranker_loader=lambda: FixedReranker([0.0, -2.0, -3.0]),
                route_top_k=3,
            )

        payload = selection.to_dict()
        self.assertTrue(payload["active"])
        self.assertEqual(payload["selection_reason"], "high_confidence_prototype")
        self.assertEqual(payload["confidence_score_floor"], ROUTING_ACTIVE_SCORE_FLOOR)
        self.assertEqual(payload["confidence_margin_floor"], ROUTING_ACTIVE_MARGIN_FLOOR)
        self.assertEqual(payload["confidence_artifact"]["mode"], "active")
        self.assertTrue(payload["confidence_artifact"]["owner_approved"])
        serialized = json.dumps(payload)
        self.assertNotIn("routing_examples", serialized)
        self.assertNotIn("routing_prototype_vector", serialized)

    def test_provisional_descriptor_free_route_forces_top_three(self) -> None:
        cards = [make_card("alpha"), make_card("beta"), make_card("gamma")]
        state = RoutingConfidenceCatalogState(
            mode="provisional",
            catalog_projection_sha256="11" * 32,
            anchor_projection_sha256=ROUTING_ACTIVE_CATALOG_PROJECTION_SHA256,
            anchor_namespaces=tuple(ROUTING_ACTIVE_ANCHOR_NAMESPACES),
            provisional_namespaces=tuple(card.namespace for card in cards),
        )
        with patch(
            "buoy_search.retrieval.routing.validate_routing_confidence_catalog",
            return_value=state,
        ):
            selection = prototype_route(
                "descriptor-free routing question",
                cards,
                calibration=anchored_routing_calibration(),
                embedder=FixedEmbedder(),
                reranker_loader=lambda: FixedReranker([100.0, 0.0, -1.0]),
                route_top_k=3,
            )

        payload = selection.to_dict()
        self.assertFalse(selection.high_confidence)
        self.assertEqual(selection.initial_fanout, 3)
        self.assertEqual(selection.selection_reason, "ambiguous_prototype")
        self.assertEqual(payload["routing_confidence_mode"], "provisional")
        self.assertFalse(payload["confidence_threshold_applied"])
        self.assertEqual(payload["provisional_namespace_count"], 3)

    def test_certified_descriptor_free_route_retains_singleton_thresholds(self) -> None:
        cards = [make_card("alpha"), make_card("beta"), make_card("gamma")]
        state = RoutingConfidenceCatalogState(
            mode="certified",
            catalog_projection_sha256=ROUTING_ACTIVE_CATALOG_PROJECTION_SHA256,
            anchor_projection_sha256=ROUTING_ACTIVE_CATALOG_PROJECTION_SHA256,
            anchor_namespaces=tuple(ROUTING_ACTIVE_ANCHOR_NAMESPACES),
            provisional_namespaces=(),
        )
        with patch(
            "buoy_search.retrieval.routing.validate_routing_confidence_catalog",
            return_value=state,
        ):
            selection = prototype_route(
                "descriptor-free routing question",
                cards,
                calibration=anchored_routing_calibration(),
                embedder=FixedEmbedder(),
                reranker_loader=lambda: FixedReranker([0.0, -2.0, -3.0]),
                route_top_k=3,
            )

        payload = selection.to_dict()
        self.assertTrue(selection.high_confidence)
        self.assertEqual(selection.initial_fanout, 1)
        self.assertEqual(payload["routing_confidence_mode"], "certified")
        self.assertTrue(payload["confidence_threshold_applied"])
        self.assertEqual(payload["provisional_namespace_count"], 0)

    def test_invalid_active_calibration_stops_before_model_work(self) -> None:
        embedder = FixedEmbedder()
        invalid = replace(
            active_routing_calibration(),
            score_floor=ROUTING_ACTIVE_SCORE_FLOOR + 0.1,
        )

        with self.assertRaisesRegex(AutomaticRoutingError, "confidence artifact"):
            prototype_route(
                "descriptor-free routing question",
                [make_card("alpha")],
                calibration=invalid,
                embedder=embedder,
                reranker_loader=lambda: (_ for _ in ()).throw(
                    AssertionError("reranker loaded")
                ),
                route_top_k=3,
            )

        self.assertEqual(embedder.calls, [])

    def test_semantic_mismatch_stops_before_model_work(self) -> None:
        embedder = FixedEmbedder()
        calibration = active_routing_calibration()
        assert calibration.semantic_compatibility is not None
        invalid = replace(
            calibration,
            semantic_compatibility=replace(
                calibration.semantic_compatibility,
                routing_algorithm="other-v1",
            ),
        )

        with self.assertRaisesRegex(AutomaticRoutingError, "confidence artifact"):
            prototype_route(
                "descriptor-free routing question",
                [make_card("alpha")],
                calibration=invalid,
                embedder=embedder,
                reranker_loader=lambda: (_ for _ in ()).throw(
                    AssertionError("reranker loaded")
                ),
                route_top_k=3,
            )

        self.assertEqual(embedder.calls, [])

    def test_prototype_shortlist_is_exact_and_bounded_to_twelve(self) -> None:
        cards = [make_card(f"card-{index:02d}") for index in range(13)]
        reranker = FixedReranker([float(index) for index in range(12)])
        scores = prototype_route_scores(
            "descriptor-free question",
            cards,
            embedder=FixedEmbedder(),
            reranker=reranker,
        )
        self.assertEqual(len(scores), 12)
        self.assertNotIn("card-12", {item.card.namespace for item in scores})
        self.assertEqual(len(reranker.calls[0][1]), 12)

    def test_each_evidence_vector_can_nominate_a_card_before_top_twelve(self) -> None:
        query_vector = unit_vector(0)
        passages = [f"Distinct routing topic {index}" for index in range(8)]
        target = make_card(
            "zz-diverse-target",
            routing_passages=passages,
            passage_vectors=[
                unit_vector(1),
                query_vector,
                *(unit_vector(index) for index in range(2, 9)),
            ],
        )
        competitors = [
            make_card(f"card-{index:02d}", vector=cosine_vector(0.4))
            for index in range(12)
        ]
        self.assertLess(target.routing_prototype_vector[0], 0.4)
        reranker = FixedReranker([0.0] * 20)

        scores = prototype_route_scores(
            "descriptor-free niche question",
            [*competitors, target],
            embedder=FixedEmbedder(query_vector),
            reranker=reranker,
        )

        self.assertEqual(len(scores), 12)
        self.assertEqual(len({item.card.namespace for item in scores}), 12)
        routed_target = next(
            item for item in scores if item.card.namespace == target.namespace
        )
        self.assertEqual(routed_target.shortlist_rank, 1)
        self.assertEqual(len(reranker.calls[0][1]), 20)

    def test_source_passage_requires_an_exact_evidence_vector_bank(self) -> None:
        card = make_card(
            "source-backed",
            routing_passages=["Source-grounded niche capability"],
        )
        missing = replace(
            card,
            routing_evidence_vectors=[],
            routing_evidence_vectors_hash="",
        )
        truncated_vectors = card.routing_evidence_vectors[:-1]
        truncated = replace(
            card,
            routing_evidence_vectors=truncated_vectors,
            routing_evidence_vectors_hash=vector_hash(truncated_vectors),
        )
        stale = replace(card, routing_evidence_vectors_hash="0" * 64)
        inconsistent_vectors = unit_vector(1)
        inconsistent = replace(
            card,
            routing_evidence_vectors=inconsistent_vectors,
            routing_evidence_vectors_hash=vector_hash(inconsistent_vectors),
        )
        example_only_v3 = replace(
            make_card(
                "example-backed-v3",
                routing_examples=["Reviewed capability question"],
            ),
            plan_schema_version=3,
            routing_evidence_vectors=[],
            routing_evidence_vectors_hash="",
        )

        for broken, diagnostic in (
            (missing, "no evidence vector bank"),
            (truncated, "invalid dimensions"),
            (stale, "vector bank is stale"),
            (inconsistent, "vector projection is stale"),
            (example_only_v3, "non-base evidence has no evidence vector bank"),
        ):
            embedder = FixedEmbedder()
            with self.subTest(diagnostic=diagnostic), self.assertRaisesRegex(
                AutomaticRoutingError,
                diagnostic,
            ):
                prototype_route_scores(
                    "descriptor-free niche question",
                    [broken],
                    embedder=embedder,
                    reranker=FixedReranker([]),
                )
            self.assertEqual(embedder.calls, [])

    def test_prototype_stage_one_is_isolated_from_legacy_base_vectors(self) -> None:
        first_axis = unit_vector(0)
        second_axis = unit_vector(1)
        base_first = make_card(
            "base-first",
            vector=first_axis,
            routing_examples=["Base-first prototype example"],
        )
        prototype_first = make_card(
            "prototype-first",
            vector=second_axis,
            routing_examples=["Prototype-first example"],
        )
        base_first = replace(
            base_first,
            routing_prototype_vector=second_axis,
            routing_prototype_vector_hash=vector_hash(second_axis),
            routing_evidence_vectors=[],
            routing_evidence_vectors_hash="",
        )
        prototype_first = replace(
            prototype_first,
            routing_prototype_vector=first_axis,
            routing_prototype_vector_hash=vector_hash(first_axis),
            routing_evidence_vectors=[],
            routing_evidence_vectors_hash="",
        )
        cards = [base_first, prototype_first]

        legacy = semantic_route(
            "descriptor-free query",
            cards,
            embedder=FixedEmbedder(first_axis),
        )
        candidate = prototype_route_scores(
            "descriptor-free query",
            cards,
            embedder=FixedEmbedder(first_axis),
            reranker=FixedReranker([1.0, 1.0, 1.0, 1.0]),
        )
        hybrid = hybrid_route(
            "descriptor-free query",
            cards,
            embedder=FixedEmbedder(first_axis),
            route_top_k=3,
        )

        self.assertEqual(legacy[0][0].namespace, "base-first")
        self.assertEqual(hybrid.selected_cards[0].namespace, "base-first")
        self.assertEqual(candidate[0].card.namespace, "prototype-first")
        self.assertEqual(candidate[0].shortlist_rank, 1)

    def test_thousand_card_catalog_keeps_one_embedding_and_twelve_local_scores(self) -> None:
        cards = [make_card(f"card-{index:04d}") for index in range(1000)]
        embedder = FixedEmbedder()
        reranker = FixedReranker([0.0] * 12)

        scores = prototype_route_scores(
            "descriptor-free scale question",
            list(reversed(cards)),
            embedder=embedder,
            reranker=reranker,
        )

        self.assertEqual(len(embedder.calls), 1)
        self.assertEqual(len(reranker.calls), 1)
        self.assertEqual(len(reranker.calls[0][1]), 12)
        self.assertEqual(
            [item.card.namespace for item in scores],
            [f"card-{index:04d}" for index in range(12)],
        )

    def test_named_quality_observation_prepends_exact_card_to_bounded_shortlist(self) -> None:
        cards = [make_card(f"card-{index:02d}") for index in range(12)]
        cards.append(make_card("zz-named", title="Named Product"))
        scores = prototype_route_scores(
            "How does Named Product work?",
            cards,
            embedder=FixedEmbedder(),
            reranker=FixedReranker([0.0] * 12),
            include_exact_names=True,
        )
        named = next(item for item in scores if item.card.namespace == "zz-named")
        self.assertEqual(named.shortlist_rank, 1)
        self.assertEqual(len(scores), 12)

    def test_prototype_scoring_enforces_the_exact_108_passage_bound(self) -> None:
        examples = [f"Capability example {index}" for index in range(8)]
        cards = [
            make_card(f"card-{index:02d}", routing_examples=examples)
            for index in range(12)
        ]
        reranker = FixedReranker([0.0] * 108)
        prototype_route_scores(
            "bounded question",
            cards,
            embedder=FixedEmbedder(),
            reranker=reranker,
        )
        self.assertEqual(len(reranker.calls[0][1]), 108)

        invalid = replace(
            cards[0],
            routing_examples=[f"Too many {index}" for index in range(9)],
        )
        embedder = FixedEmbedder()
        with self.assertRaisesRegex(AutomaticRoutingError, "at most 8"):
            prototype_route_scores(
                "question",
                [invalid],
                embedder=embedder,
                reranker=FixedReranker([]),
            )
        self.assertEqual(embedder.calls, [])

        overlong = replace(cards[0], routing_examples=["q" * 513])
        with self.assertRaisesRegex(AutomaticRoutingError, "examples are invalid"):
            prototype_route_scores(
                "question",
                [overlong],
                embedder=FixedEmbedder(),
                reranker=FixedReranker([]),
            )

        stale = replace(
            cards[0],
            routing_prototype_vector_hash="0" * 64,
        )
        stale_embedder = FixedEmbedder()
        with self.assertRaisesRegex(AutomaticRoutingError, "projection is stale"):
            prototype_route_scores(
                "question",
                [stale],
                embedder=stale_embedder,
                reranker=FixedReranker([]),
            )
        self.assertEqual(stale_embedder.calls, [])

    def test_named_prototype_route_preserves_shortcut_and_skips_reranker(self) -> None:
        class FailingReranker:
            def score(self, _query, _passages):  # noqa: ANN001
                raise AssertionError("named route loaded reranker")

        embedder = FixedEmbedder()
        selection = prototype_route(
            "How does Dagster model assets?",
            [
                make_card("dagster", title="Dagster"),
                make_card("other", title="Other"),
            ],
            calibration=load_collect_routing_confidence_fixture(),
            embedder=embedder,
            reranker_loader=lambda: FailingReranker(),
            route_top_k=3,
        )
        self.assertEqual(len(embedder.calls), 1)
        self.assertEqual(selection.initial_fanout, 1)
        self.assertEqual(selection.selection_reason, "unique_title_or_alias")
        self.assertEqual(selection.selected_cards[0].namespace, "dagster")

    def test_named_prototype_route_does_not_construct_reranker(self) -> None:
        with patch(
            "buoy_search.retrieval.routing.validate_routing_confidence_catalog",
            return_value=ROUTING_ACTIVE_CATALOG_PROJECTION_SHA256,
        ):
            selection = prototype_route(
                "How does Dagster model assets?",
                [make_card("dagster", title="Dagster"), make_card("other")],
                calibration=active_routing_calibration(),
                embedder=FixedEmbedder(),
                reranker_loader=lambda: (_ for _ in ()).throw(
                    AssertionError("named route constructed reranker")
                ),
                route_top_k=3,
            )
        self.assertEqual(selection.selection_reason, "unique_title_or_alias")
        self.assertTrue(selection.to_dict()["active"])

    def test_prototype_reranker_failure_is_redacted(self) -> None:
        secret = "routing-prototype-secret"

        class LeakyReranker:
            def score(self, _query, _passages):  # noqa: ANN001
                raise RuntimeError(f"Bearer {secret}")

        with self.assertRaisesRegex(
            AutomaticRoutingError, "routing shortlist reranking failed"
        ) as raised:
            prototype_route_scores(
                "query",
                [make_card("one")],
                embedder=FixedEmbedder(),
                reranker=LeakyReranker(),
            )
        self.assertNotIn(secret, str(raised.exception))

    def test_prototype_reranker_loader_failure_is_redacted(self) -> None:
        secret = "routing-loader-secret"

        with self.assertRaisesRegex(
            AutomaticRoutingError, "routing shortlist reranker loading failed"
        ) as raised:
            prototype_route(
                "descriptor-free query",
                [make_card("one")],
                calibration=load_collect_routing_confidence_fixture(),
                embedder=FixedEmbedder(),
                reranker_loader=lambda: (_ for _ in ()).throw(
                    RuntimeError(f"Bearer {secret}")
                ),
                route_top_k=3,
            )
        self.assertNotIn(secret, str(raised.exception))

    def test_empty_prototype_cards_fail_before_model_work(self) -> None:
        embedder = FixedEmbedder()
        reranker = FixedReranker([])
        with self.assertRaisesRegex(AutomaticRoutingError, "at least one eligible"):
            prototype_route_scores(
                "query",
                [],
                embedder=embedder,
                reranker=reranker,
            )
        self.assertEqual(embedder.calls, [])
        self.assertEqual(reranker.calls, [])

    def test_base_and_card_score_ties_keep_frozen_order_and_null_index(self) -> None:
        cards = [
            make_card("alpha", routing_examples=["Example"]),
            make_card("beta"),
        ]
        scores = prototype_route_scores(
            "query",
            cards,
            embedder=FixedEmbedder(),
            reranker=FixedReranker([2.0, 2.0, 2.0]),
        )
        self.assertEqual([item.card.namespace for item in scores], ["alpha", "beta"])
        self.assertEqual(scores[0].winning_prototype_kind, "card")
        selection = prototype_route(
            "query",
            cards,
            calibration=load_collect_routing_confidence_fixture(),
            embedder=FixedEmbedder(),
            reranker_loader=lambda: FixedReranker([2.0, 2.0, 2.0]),
            route_top_k=3,
        )
        first = selection.to_dict()["selected_cards"][0]
        self.assertIn("winning_prototype_index", first)
        self.assertIsNone(first["winning_prototype_index"])

    def test_malformed_prototype_score_sequence_fails_safely(self) -> None:
        class InvalidReranker:
            def score(self, _query, _passages):  # noqa: ANN001
                return object()

        with self.assertRaisesRegex(AutomaticRoutingError, "invalid score sequence"):
            prototype_route_scores(
                "query",
                [make_card("one")],
                embedder=FixedEmbedder(),
                reranker=InvalidReranker(),
            )

    def test_prototype_embedder_failure_is_redacted(self) -> None:
        secret = "routing-embedder-secret"

        class LeakyEmbedder:
            def encode(self, _texts):  # noqa: ANN001
                raise RuntimeError(f"Bearer {secret}")

        with self.assertRaisesRegex(
            AutomaticRoutingError, "routing query embedding failed"
        ) as raised:
            prototype_route_scores(
                "query",
                [make_card("one")],
                embedder=LeakyEmbedder(),
                reranker=FixedReranker([1.0]),
            )
        self.assertNotIn(secret, str(raised.exception))


class AutomaticRoutingCliTests(unittest.TestCase):
    API_KEY = "tpuf_test-routing-secret"

    def setUp(self) -> None:
        self.worker_capability_patch = patch(
            "buoy_search.cli.main.EMBEDDING_WORKER_CAPABILITY_FACTORY",
            return_value=False,
        )
        self.worker_capability_patch.start()

    def tearDown(self) -> None:
        self.worker_capability_patch.stop()

    def _run_preview(self, query: str, cards: list[NamespaceCard], *, extra_live=()):
        catalog_snapshot = snapshot(cards, extra_live=extra_live)
        with patch(
            "buoy_search.cli.main.REMOTE_CATALOG_CLIENT_FACTORY", return_value=object()
        ), patch(
            "buoy_search.cli.main.read_remote_catalog", return_value=catalog_snapshot
        ), patch(
            "buoy_search.cli.main.ROUTING_CONFIDENCE_FACTORY",
            return_value=load_collect_routing_confidence_fixture(),
        ), patch(
            "buoy_search.cli.main.ROUTING_EMBEDDER_FACTORY", return_value=FixedEmbedder()
        ):
            return run_cli(
                ["retrieve", query, "--plan", "--json"],
                env={"TURBOPUFFER_API_KEY": self.API_KEY},
            )

    def test_automatic_preview_reports_route_without_querying_content(self) -> None:
        cards = [
            make_card("dagster", title="Dagster", vector=cosine_vector(0.5)),
            make_card("tpuf", title="Turbopuffer", vector=cosine_vector(0.9)),
            make_card("thistle", title="Thistle", vector=cosine_vector(0.2)),
        ]
        result, stdout, stderr = self._run_preview("Dagster assets", cards)
        payload = json.loads(stdout)
        self.assertEqual((result, stderr), (0, ""))
        self.assertTrue(payload["dry_run"])
        self.assertTrue(payload["credentials_required"])
        self.assertTrue(payload["turbopuffer_api_calls"])
        self.assertFalse(payload["content_retrieval_occurred"])
        self.assertEqual(payload["routing"]["selection_reason"], "unique_title_or_alias")
        self.assertEqual(payload["routing"]["initial_fanout"], 1)
        self.assertEqual(payload["initial_fanout"], 1)
        self.assertEqual(payload["namespaces"][0], "dagster")
        self.assertEqual(payload["evidence"]["mode"], "active")
        self.assertEqual(
            payload["evidence"]["status"], "requires_content_retrieval"
        )
        self.assertEqual(payload["evidence"]["threshold"], -8.0)
        self.assertEqual(
            payload["evidence"]["enforcement_scope"],
            "automatic_live_retrieval",
        )
        self.assertNotIn("vector", json.dumps(payload["routing"]["selected_cards"]))

    def test_automatic_live_wires_governed_evidence_assessment(self) -> None:
        cards = [
            make_card("dagster", title="Dagster", vector=cosine_vector(0.5)),
            make_card("tpuf", title="Turbopuffer", vector=cosine_vector(0.9)),
            make_card("thistle", title="Thistle", vector=cosine_vector(0.2)),
        ]
        catalog_snapshot = snapshot(cards)
        captured: dict[str, object] = {}

        class FakeResult:
            def to_dict(self) -> dict[str, object]:
                return {
                    "command": "retrieve",
                    "dry_run": False,
                    "content_retrieval_occurred": True,
                    "namespaces": ["dagster"],
                    "hits": [],
                    "evidence": {"mode": "active", "status": "supported"},
                }

        class FakeRetriever:
            def retrieve(self, _query, _options, **kwargs):  # noqa: ANN001
                captured.update(kwargs)
                return FakeResult()

        with patch(
            "buoy_search.cli.main.REMOTE_CATALOG_CLIENT_FACTORY", return_value=object()
        ), patch(
            "buoy_search.cli.main.read_remote_catalog", return_value=catalog_snapshot
        ), patch(
            "buoy_search.cli.main.ROUTING_CONFIDENCE_FACTORY",
            return_value=load_collect_routing_confidence_fixture(),
        ), patch(
            "buoy_search.cli.main.ROUTING_EMBEDDER_FACTORY", return_value=FixedEmbedder()
        ), patch(
            "buoy_search.cli.main.MultiNamespaceRetriever.from_configs",
            return_value=FakeRetriever(),
        ):
            result, stdout, stderr = run_cli(
                ["retrieve", "Dagster assets", "--json"],
                env={"TURBOPUFFER_API_KEY": self.API_KEY},
            )

        self.assertEqual((result, stderr), (0, ""))
        self.assertEqual(json.loads(stdout)["evidence"]["status"], "supported")
        self.assertIsInstance(
            captured["evidence_assessor"], CalibratedEvidenceAssessor
        )
        route_context = captured["evidence_route_context"]
        self.assertIsInstance(route_context, EvidenceRouteContext)
        self.assertEqual(route_context.selection_reason, "unique_title_or_alias")

    def test_automatic_dry_run_uses_default_worker_only_for_routing(self) -> None:
        from buoy_search.cli.main import _CommandEmbeddingWorkerSession

        cards = [
            make_card("dagster", title="Dagster", vector=cosine_vector(0.5)),
            make_card("tpuf", title="Turbopuffer", vector=cosine_vector(0.9)),
            make_card("thistle", title="Thistle", vector=cosine_vector(0.2)),
        ]
        worker_embedder = FixedEmbedder()
        session = _CommandEmbeddingWorkerSession(
            worker_embedder.encode,
            warning_callback=lambda _message: None,
        )
        with patch(
            "buoy_search.cli.main.REMOTE_CATALOG_CLIENT_FACTORY", return_value=object()
        ), patch(
            "buoy_search.cli.main.read_remote_catalog", return_value=snapshot(cards)
        ), patch(
            "buoy_search.cli.main.ROUTING_CONFIDENCE_FACTORY",
            return_value=load_collect_routing_confidence_fixture(),
        ), patch(
            "buoy_search.cli.main._prepare_default_embedding_worker",
            return_value=session,
        ) as prepare, patch(
            "buoy_search.cli.main.ROUTING_EMBEDDER_FACTORY",
            side_effect=AssertionError("in-process routing model constructed"),
        ), patch(
            "buoy_search.cli.main.MultiNamespaceRetriever.from_configs",
            side_effect=AssertionError("content retriever constructed"),
        ):
            result, stdout, stderr = run_cli(
                [
                    "retrieve",
                    "approximate vector recall",
                    "--dry-run",
                    "--json",
                ],
                env={"TURBOPUFFER_API_KEY": self.API_KEY},
            )

        self.assertEqual((result, stderr), (0, ""))
        self.assertEqual(len(worker_embedder.calls), 1)
        self.assertTrue(worker_embedder.calls[0][0].startswith(ROUTING_QUERY_PREFIX))
        self.assertTrue(prepare.call_args.kwargs["activate"])
        self.assertFalse(prepare.call_args.kwargs["disabled"])
        self.assertFalse(json.loads(stdout)["content_retrieval_occurred"])

    def test_active_automatic_preview_scores_prototypes_through_worker(self) -> None:
        from buoy_search.cli.main import _CommandEmbeddingWorkerSession

        cards = [
            make_card("one", vector=cosine_vector(0.9)),
            make_card("two", vector=cosine_vector(0.5)),
            make_card("three", vector=cosine_vector(0.2)),
        ]
        worker_embedder = FixedEmbedder()
        score_calls: list[tuple[str, list[str]]] = []

        def worker_score(query, passages):  # noqa: ANN001
            score_calls.append((query, list(passages)))
            return [float(len(passages) - index) for index in range(len(passages))]

        session = _CommandEmbeddingWorkerSession(
            worker_embedder.encode,
            warning_callback=lambda _message: None,
            score_callback=worker_score,
        )
        with patch(
            "buoy_search.cli.main.REMOTE_CATALOG_CLIENT_FACTORY",
            return_value=object(),
        ), patch(
            "buoy_search.cli.main.read_remote_catalog", return_value=snapshot(cards)
        ), patch(
            "buoy_search.cli.main.ROUTING_CONFIDENCE_FACTORY",
            return_value=active_routing_calibration(),
        ), patch(
            "buoy_search.retrieval.routing.validate_routing_confidence_catalog",
            return_value="approved-projection",
        ), patch(
            "buoy_search.cli.main._prepare_default_embedding_worker",
            return_value=session,
        ), patch(
            "buoy_search.cli.main.ROUTING_EMBEDDER_FACTORY",
            side_effect=AssertionError("in-process routing embedder constructed"),
        ), patch(
            "buoy_search.cli.main.ROUTING_RERANKER_FACTORY",
            side_effect=AssertionError("in-process reranker constructed"),
        ):
            result, stdout, stderr = run_cli(
                ["retrieve", "descriptor free question", "--dry-run", "--json"],
                env={"TURBOPUFFER_API_KEY": self.API_KEY},
            )

        self.assertEqual((result, stderr), (0, ""))
        self.assertEqual(len(worker_embedder.calls), 1)
        self.assertEqual(len(score_calls), 1)
        self.assertEqual(score_calls[0][0], "descriptor free question")
        self.assertGreaterEqual(len(score_calls[0][1]), 3)
        self.assertFalse(json.loads(stdout)["content_retrieval_occurred"])

    def test_exact_108_passage_automatic_route_stays_worker_resident(self) -> None:
        from buoy_search.cli.main import _CommandEmbeddingWorkerSession

        examples = [f"Capability example {index}" for index in range(8)]
        cards = [
            make_card(
                f"card-{index:02d}",
                vector=cosine_vector(0.9 - index * 0.01),
                routing_examples=examples,
            )
            for index in range(12)
        ]
        worker_embedder = FixedEmbedder()
        score_calls: list[tuple[str, list[str]]] = []
        warnings: list[str] = []

        def worker_score(query, passages):  # noqa: ANN001
            score_calls.append((query, list(passages)))
            return [float(len(passages) - index) for index in range(len(passages))]

        session = _CommandEmbeddingWorkerSession(
            worker_embedder.encode,
            warning_callback=warnings.append,
            score_callback=worker_score,
        )
        with patch(
            "buoy_search.cli.main.REMOTE_CATALOG_CLIENT_FACTORY",
            return_value=object(),
        ), patch(
            "buoy_search.cli.main.read_remote_catalog", return_value=snapshot(cards)
        ), patch(
            "buoy_search.cli.main.ROUTING_CONFIDENCE_FACTORY",
            return_value=active_routing_calibration(),
        ), patch(
            "buoy_search.retrieval.routing.validate_routing_confidence_catalog",
            return_value="approved-projection",
        ), patch(
            "buoy_search.cli.main._prepare_default_embedding_worker",
            return_value=session,
        ), patch(
            "buoy_search.cli.main.ROUTING_EMBEDDER_FACTORY",
            side_effect=AssertionError("in-process routing embedder constructed"),
        ), patch(
            "buoy_search.cli.main.ROUTING_RERANKER_FACTORY",
            side_effect=AssertionError("in-process reranker fallback constructed"),
        ):
            result, stdout, stderr = run_cli(
                ["retrieve", "bounded routing question", "--dry-run", "--json"],
                env={"TURBOPUFFER_API_KEY": self.API_KEY},
            )

        self.assertEqual((result, stderr), (0, ""))
        self.assertEqual(warnings, [])
        self.assertEqual(len(worker_embedder.calls), 1)
        self.assertEqual(len(score_calls), 1)
        self.assertEqual(score_calls[0][0], "bounded routing question")
        self.assertEqual(len(score_calls[0][1]), 108)
        self.assertFalse(session._worker_failed)
        self.assertFalse(json.loads(stdout)["content_retrieval_occurred"])

    def test_active_route_worker_and_reranker_fallback_failure_is_model_error(self) -> None:
        from buoy_search.cli.main import (
            _CommandEmbeddingWorkerSession,
            _print_embedding_worker_fallback_warning,
        )

        cards = [make_card("one"), make_card("two"), make_card("three")]
        session = _CommandEmbeddingWorkerSession(
            FixedEmbedder().encode,
            warning_callback=_print_embedding_worker_fallback_warning,
            score_callback=lambda _query, _passages: (_ for _ in ()).throw(
                RuntimeError("private worker score")
            ),
        )
        with patch(
            "buoy_search.cli.main.REMOTE_CATALOG_CLIENT_FACTORY",
            return_value=object(),
        ), patch(
            "buoy_search.cli.main.read_remote_catalog", return_value=snapshot(cards)
        ), patch(
            "buoy_search.cli.main.ROUTING_CONFIDENCE_FACTORY",
            return_value=active_routing_calibration(),
        ), patch(
            "buoy_search.retrieval.routing.validate_routing_confidence_catalog",
            return_value="approved-projection",
        ), patch(
            "buoy_search.cli.main._prepare_default_embedding_worker",
            return_value=session,
        ), patch(
            "buoy_search.cli.main.ROUTING_EMBEDDER_FACTORY",
            side_effect=AssertionError("in-process embedder constructed"),
        ), patch(
            "buoy_search.cli.main.ROUTING_RERANKER_FACTORY",
            side_effect=RuntimeError("private fallback model"),
        ), patch(
            "buoy_search.cli.main.MultiNamespaceRetriever.from_configs",
            side_effect=AssertionError("content retriever constructed"),
        ):
            result, stdout, stderr = run_cli(
                ["retrieve", "descriptor free question", "--dry-run", "--json"],
                env={"TURBOPUFFER_API_KEY": self.API_KEY},
            )

        self.assertEqual((result, stdout), (2, ""))
        self.assertEqual(
            stderr,
            "Warning: local embedding worker failed; using in-process embedding for this command.\n"
            "Automatic routing failed: in-process reranker fallback failed.\n",
        )
        self.assertNotIn("private", stderr)

    def test_worker_session_reuses_one_reranker_adapter(self) -> None:
        from buoy_search.cli.main import _CommandEmbeddingWorkerSession

        score_calls: list[tuple[str, list[str]]] = []

        def worker_score(query, passages):  # noqa: ANN001
            score_calls.append((query, list(passages)))
            return [0.5] * len(passages)

        session = _CommandEmbeddingWorkerSession(
            lambda _texts: [[1.0]],
            warning_callback=lambda _message: None,
            score_callback=worker_score,
        )
        fallback_factory = Mock(
            side_effect=AssertionError("in-process reranker constructed")
        )

        first = session.reranker(fallback_factory)
        second = session.reranker(fallback_factory)

        self.assertIs(first, second)
        self.assertEqual(first.score("query", ["one", "two"]), [0.5, 0.5])
        self.assertEqual(score_calls, [("query", ["one", "two"])])
        fallback_factory.assert_not_called()

    def test_score_failure_switches_later_embedding_in_process_with_one_warning(self) -> None:
        from buoy_search.cli.main import _CommandEmbeddingWorkerSession

        warnings: list[str] = []
        worker_encode = Mock(side_effect=AssertionError("worker encode retried"))
        worker_score = Mock(side_effect=RuntimeError("private worker score"))
        fallback_embedder = FixedEmbedder()

        class FallbackReranker:
            def score(self, _query, passages):  # noqa: ANN001
                return [0.25] * len(passages)

        session = _CommandEmbeddingWorkerSession(
            worker_encode,
            warning_callback=warnings.append,
            score_callback=worker_score,
        )
        reranker = session.reranker(lambda: FallbackReranker())

        self.assertEqual(reranker.score("query", ["one"]), [0.25])
        embedder = session.embedder("routing", lambda: fallback_embedder)
        embedder.encode(["later"])

        self.assertEqual(len(warnings), 1)
        self.assertNotIn("private", warnings[0])
        self.assertEqual(fallback_embedder.calls, [["later"]])
        self.assertEqual(worker_score.call_count, 1)
        worker_encode.assert_not_called()

    def test_default_worker_session_is_shared_by_automatic_route_and_retrieval(self) -> None:
        from buoy_search.cli.main import _CommandEmbeddingWorkerSession

        cards = [
            make_card("dagster", title="Dagster", vector=cosine_vector(0.5)),
            make_card("tpuf", title="Turbopuffer", vector=cosine_vector(0.9)),
            make_card("thistle", title="Thistle", vector=cosine_vector(0.2)),
        ]
        catalog_snapshot = snapshot(cards)
        worker_embedder = FixedEmbedder()
        session = _CommandEmbeddingWorkerSession(
            worker_embedder.encode,
            warning_callback=lambda _message: None,
        )
        captured: list[tuple[object, object]] = []
        retrieve_kwargs: dict[str, object] = {}

        class FakeResult:
            def to_dict(self) -> dict[str, object]:
                return {
                    "command": "retrieve",
                    "dry_run": False,
                    "content_retrieval_occurred": True,
                    "namespaces": ["tpuf"],
                    "embedding_precision": "float32",
                    "fusion": "cross_namespace_equal_weight_ordinal_rrf",
                    "hits": [],
                    "evidence": {"mode": "active", "status": "supported"},
                }

        class FakeRetriever:
            def __init__(self, embedder: object) -> None:
                self.embedder = embedder

            def retrieve(self, query, _options, **kwargs):  # noqa: ANN001
                retrieve_kwargs.update(kwargs)
                self.embedder.encode([query])
                return FakeResult()

        def construct(  # noqa: ANN001
            _configs, *, embedder, reranker_loader
        ):
            captured.append((embedder, reranker_loader))
            return FakeRetriever(embedder)

        with patch(
            "buoy_search.cli.main.REMOTE_CATALOG_CLIENT_FACTORY", return_value=object()
        ), patch(
            "buoy_search.cli.main.read_remote_catalog", return_value=catalog_snapshot
        ), patch(
            "buoy_search.cli.main.ROUTING_CONFIDENCE_FACTORY",
            return_value=load_collect_routing_confidence_fixture(),
        ), patch(
            "buoy_search.cli.main._prepare_default_embedding_worker",
            return_value=session,
        ) as prepare, patch(
            "buoy_search.cli.main.ROUTING_EMBEDDER_FACTORY",
            side_effect=AssertionError("in-process routing model constructed"),
        ), patch(
            "buoy_search.cli.main.MultiNamespaceRetriever.from_configs",
            side_effect=construct,
        ):
            result, stdout, stderr = run_cli(
                ["retrieve", "approximate vector recall", "--json"],
                env={"TURBOPUFFER_API_KEY": self.API_KEY},
            )

        self.assertEqual((result, stderr), (0, ""))
        self.assertEqual(len(captured), 1)
        reranker_loader = captured[0][1]
        self.assertTrue(callable(reranker_loader))
        assessor = retrieve_kwargs["evidence_assessor"]
        self.assertIsInstance(assessor, CalibratedEvidenceAssessor)
        self.assertIs(assessor._reranker_loader(), reranker_loader())
        self.assertEqual(len(worker_embedder.calls), 2)
        self.assertTrue(worker_embedder.calls[0][0].startswith(ROUTING_QUERY_PREFIX))
        self.assertEqual(worker_embedder.calls[1], ["approximate vector recall"])
        self.assertTrue(prepare.call_args.kwargs["activate"])
        self.assertFalse(prepare.call_args.kwargs["disabled"])
        self.assertNotIn("embedding_worker", stdout)

    def test_worker_route_failure_switches_whole_command_without_provider_replay(self) -> None:
        from buoy_search.cli.main import _CommandEmbeddingWorkerSession

        cards = [
            make_card("dagster", title="Dagster", vector=cosine_vector(0.5)),
            make_card("tpuf", title="Turbopuffer", vector=cosine_vector(0.9)),
            make_card("thistle", title="Thistle", vector=cosine_vector(0.2)),
        ]
        worker_calls: list[list[str]] = []
        warnings: list[str] = []
        route_fallback = FixedEmbedder()
        retrieval_fallback = FixedEmbedder()
        catalog_calls: list[object] = []
        content_calls: list[str] = []

        def failed_worker(texts):  # noqa: ANN001
            worker_calls.append(list(texts))
            raise RuntimeError("private-worker-detail")

        session = _CommandEmbeddingWorkerSession(
            failed_worker,
            warning_callback=warnings.append,
        )

        class FakeResult:
            def to_dict(self) -> dict[str, object]:
                return {
                    "command": "retrieve",
                    "dry_run": False,
                    "content_retrieval_occurred": True,
                    "namespaces": ["tpuf"],
                    "embedding_precision": "float32",
                    "fusion": "cross_namespace_equal_weight_ordinal_rrf",
                    "hits": [],
                    "evidence": {"mode": "active", "status": "supported"},
                }

        class FakeRetriever:
            def __init__(self, embedder: object) -> None:
                self.embedder = embedder

            def retrieve(self, query, _options, **_kwargs):  # noqa: ANN001
                content_calls.append(query)
                self.embedder.encode([query])
                return FakeResult()

        def read_catalog(*args, **kwargs):  # noqa: ANN002,ANN003
            catalog_calls.append((args, kwargs))
            return snapshot(cards)

        def construct(  # noqa: ANN001
            _configs, *, embedder, reranker_loader
        ):
            self.assertIsNotNone(reranker_loader)
            return FakeRetriever(embedder)

        with patch(
            "buoy_search.cli.main.REMOTE_CATALOG_CLIENT_FACTORY", return_value=object()
        ), patch(
            "buoy_search.cli.main.read_remote_catalog", side_effect=read_catalog
        ), patch(
            "buoy_search.cli.main.ROUTING_CONFIDENCE_FACTORY",
            return_value=load_collect_routing_confidence_fixture(),
        ), patch(
            "buoy_search.cli.main._prepare_default_embedding_worker",
            return_value=session,
        ), patch(
            "buoy_search.cli.main.ROUTING_EMBEDDER_FACTORY",
            return_value=route_fallback,
        ), patch(
            "buoy_search.cli.main.IN_PROCESS_RETRIEVAL_EMBEDDER_FACTORY",
            return_value=retrieval_fallback,
        ) as retrieval_factory, patch(
            "buoy_search.cli.main.MultiNamespaceRetriever.from_configs",
            side_effect=construct,
        ) as construct_retriever:
            result, _stdout, stderr = run_cli(
                ["retrieve", "approximate vector recall", "--json"],
                env={"TURBOPUFFER_API_KEY": self.API_KEY},
            )

        self.assertEqual((result, stderr), (0, ""))
        self.assertEqual(len(worker_calls), 1)
        self.assertEqual(len(route_fallback.calls), 1)
        self.assertEqual(retrieval_fallback.calls, [["approximate vector recall"]])
        self.assertEqual(len(warnings), 1)
        self.assertNotIn("private-worker-detail", warnings[0])
        self.assertEqual(len(catalog_calls), 1)
        self.assertEqual(construct_retriever.call_count, 1)
        self.assertEqual(content_calls, ["approximate vector recall"])
        self.assertEqual(retrieval_factory.call_count, 1)

    def test_worker_and_automatic_fallback_failure_is_redacted_model_error(self) -> None:
        from buoy_search.cli.main import (
            _CommandEmbeddingWorkerSession,
            _print_embedding_worker_fallback_warning,
        )

        worker_secret = "private-worker-detail"
        fallback_secret = "private-fallback-detail"
        cards = [
            make_card("dagster", title="Dagster", vector=cosine_vector(0.5)),
            make_card("tpuf", title="Turbopuffer", vector=cosine_vector(0.9)),
            make_card("thistle", title="Thistle", vector=cosine_vector(0.2)),
        ]
        catalog_calls: list[object] = []

        class FailingFallbackEmbedder:
            def encode(self, _texts):  # noqa: ANN001
                raise RuntimeError(fallback_secret)

        session = _CommandEmbeddingWorkerSession(
            lambda _texts: (_ for _ in ()).throw(RuntimeError(worker_secret)),
            warning_callback=_print_embedding_worker_fallback_warning,
        )

        def read_catalog(*args, **kwargs):  # noqa: ANN002,ANN003
            catalog_calls.append((args, kwargs))
            return snapshot(cards)

        with patch(
            "buoy_search.cli.main.REMOTE_CATALOG_CLIENT_FACTORY", return_value=object()
        ) as provider_construct, patch(
            "buoy_search.cli.main.read_remote_catalog", side_effect=read_catalog
        ), patch(
            "buoy_search.cli.main.ROUTING_CONFIDENCE_FACTORY",
            return_value=load_collect_routing_confidence_fixture(),
        ), patch(
            "buoy_search.cli.main._prepare_default_embedding_worker",
            return_value=session,
        ), patch(
            "buoy_search.cli.main.ROUTING_EMBEDDER_FACTORY",
            return_value=FailingFallbackEmbedder(),
        ) as fallback_factory, patch(
            "buoy_search.cli.main.MultiNamespaceRetriever.from_configs",
            side_effect=AssertionError("content retriever constructed"),
        ) as content_construct:
            result, stdout, stderr = run_cli(
                ["retrieve", "approximate vector recall", "--json"],
                env={"TURBOPUFFER_API_KEY": self.API_KEY},
            )

        self.assertEqual(result, 2)
        self.assertEqual(stdout, "")
        self.assertEqual(provider_construct.call_count, 1)
        self.assertEqual(len(catalog_calls), 1)
        self.assertEqual(fallback_factory.call_count, 1)
        self.assertEqual(content_construct.call_count, 0)
        self.assertEqual(
            stderr,
            "Warning: local embedding worker failed; using in-process embedding for this command.\n"
            "Automatic routing failed: in-process embedding fallback failed.\n",
        )
        self.assertNotIn(worker_secret, stderr)
        self.assertNotIn(fallback_secret, stderr)
        self.assertNotIn("routing query embedding failed", stderr)

    def test_plain_automatic_retrieval_wires_active_evidence_assessment(self) -> None:
        cards = [
            make_card("dagster", title="Dagster", vector=cosine_vector(0.5)),
            make_card("tpuf", title="Turbopuffer", vector=cosine_vector(0.9)),
            make_card("thistle", title="Thistle", vector=cosine_vector(0.2)),
        ]
        catalog_snapshot = snapshot(cards)
        captured: dict[str, object] = {}
        assessor = object()

        class FakeResult:
            def to_dict(self) -> dict[str, object]:
                return {
                    "command": "retrieve",
                    "dry_run": False,
                    "content_retrieval_occurred": True,
                    "namespaces": ["dagster"],
                    "embedding_precision": "float32",
                    "fusion": "cross_namespace_equal_weight_ordinal_rrf",
                    "hits": [
                        {
                            "id": "dagster-hit",
                            "title": "Dagster assets",
                            "url": "https://docs.dagster.io/guides/build/assets",
                            "content": "Assets model persistent objects.",
                        }
                    ],
                    "evidence": {"mode": "active", "status": "supported"},
                }

        class FakeRetriever:
            def retrieve(self, _query, _options, **kwargs):  # noqa: ANN001
                captured.update(kwargs)
                return FakeResult()

        with patch(
            "buoy_search.cli.main.REMOTE_CATALOG_CLIENT_FACTORY", return_value=object()
        ), patch(
            "buoy_search.cli.main.read_remote_catalog", return_value=catalog_snapshot
        ), patch(
            "buoy_search.cli.main.ROUTING_CONFIDENCE_FACTORY",
            return_value=load_collect_routing_confidence_fixture(),
        ), patch(
            "buoy_search.cli.main.ROUTING_EMBEDDER_FACTORY", return_value=FixedEmbedder()
        ), patch(
            "buoy_search.cli.main.MultiNamespaceRetriever.from_configs",
            return_value=FakeRetriever(),
        ), patch(
            "buoy_search.cli.main.CalibratedEvidenceAssessor",
            return_value=assessor,
        ):
            result, stdout, stderr = run_cli(
                ["retrieve", "Dagster assets"],
                env={"TURBOPUFFER_API_KEY": self.API_KEY},
            )

        self.assertEqual((result, stderr), (0, ""))
        self.assertEqual(
            stdout,
            "Found 1 passage.\n\n"
            "1. Dagster assets\n"
            "   https://docs.dagster.io/guides/build/assets\n"
            "   Assets model persistent objects.\n",
        )
        self.assertIs(captured["evidence_assessor"], assessor)
        self.assertIsInstance(
            captured["evidence_route_context"], EvidenceRouteContext
        )
        self.assertEqual(captured["initial_fanout"], 1)

    def test_catalog_resource_failure_cannot_leak_credentials(self) -> None:
        secret = "tpuf_AUTO_RESOURCE_SECRET"

        class LeakyProviderError(Exception):
            pass

        class ResourceExplodingClient:
            def namespaces(self, **_kwargs: object) -> object:
                return [
                    {"id": REMOTE_CATALOG_NAMESPACE},
                    {"id": "site-example-v1"},
                ]

            def namespace(self, _namespace: str) -> object:
                raise LeakyProviderError(f"Bearer {secret}")

        with patch(
            "buoy_search.cli.main.REMOTE_CATALOG_CLIENT_FACTORY",
            return_value=ResourceExplodingClient(),
        ), patch(
            "buoy_search.cli.main.ROUTING_EMBEDDER_FACTORY",
            side_effect=AssertionError("routing model loaded after catalog failure"),
        ):
            result, stdout, stderr = run_cli(
                ["retrieve", "routing question", "--plan", "--json"],
                env={"TURBOPUFFER_API_KEY": secret},
            )

        self.assertEqual((result, stdout), (2, ""))
        self.assertIn("namespace resource acquisition", stderr)
        self.assertIn("LeakyProviderError", stderr)
        self.assertNotIn(secret, stderr)
        self.assertNotIn("Bearer", stderr)

    def test_missing_or_incompatible_live_cards_are_reported_without_hiding_valid_cards(self) -> None:
        cards = [
            make_card("eligible"),
            make_card("incompatible", embedding_precision="float16"),
        ]
        catalog_snapshot = snapshot(cards, extra_live=("missing",))
        with patch(
            "buoy_search.cli.main.REMOTE_CATALOG_CLIENT_FACTORY", return_value=object()
        ), patch(
            "buoy_search.cli.main.read_remote_catalog", return_value=catalog_snapshot
        ), patch(
            "buoy_search.cli.main.ROUTING_CONFIDENCE_FACTORY",
            return_value=load_collect_routing_confidence_fixture(),
        ), patch(
            "buoy_search.cli.main.ROUTING_EMBEDDER_FACTORY", return_value=FixedEmbedder()
        ):
            result, stdout, stderr = run_cli(
                ["retrieve", "query", "--plan", "--json"],
                env={"TURBOPUFFER_API_KEY": self.API_KEY},
            )
        payload = json.loads(stdout)
        self.assertEqual((result, stderr), (0, ""))
        self.assertEqual(payload["namespaces"], ["eligible"])
        self.assertEqual(
            payload["routing"]["exclusion_counts"],
            {"incompatible": 1, "missing_card": 1},
        )
        self.assertEqual(
            payload["routing"]["exclusion_ids"],
            {"incompatible": ["incompatible"], "missing_card": ["missing"]},
        )

    def test_invalid_evidence_artifact_fails_before_provider_work(self) -> None:
        with patch(
            "buoy_search.cli.main.load_evidence_calibration",
            side_effect=EvidenceCalibrationError("artifact is incompatible"),
        ), patch(
            "buoy_search.cli.main.REMOTE_CATALOG_CLIENT_FACTORY",
            side_effect=AssertionError("catalog client constructed"),
        ):
            result, stdout, stderr = run_cli(
                ["retrieve", "query", "--plan", "--json"],
                env={"TURBOPUFFER_API_KEY": self.API_KEY},
            )

        self.assertEqual((result, stdout), (2, ""))
        self.assertIn("Automatic evidence assessment failed", stderr)
        self.assertIn("artifact is incompatible", stderr)

    def test_disabled_and_stale_cards_are_covered_but_excluded(self) -> None:
        eligible = make_card("eligible", vector=unit_vector())
        disabled = make_card("disabled", enabled=False, vector=unit_vector())
        stale = make_card("stale", vector=unit_vector())
        catalog_snapshot = classify_remote_catalog(
            live_namespace_ids=(REMOTE_CATALOG_NAMESPACE, "eligible", "disabled"),
            cards=(eligible, disabled, stale),
            compatibility=CompatibilityContract(
                region="gcp-us-central1",
                embedding_model=ROUTING_MODEL,
                embedding_precision="float32",
            ),
        )
        with patch(
            "buoy_search.cli.main.REMOTE_CATALOG_CLIENT_FACTORY", return_value=object()
        ), patch(
            "buoy_search.cli.main.read_remote_catalog", return_value=catalog_snapshot
        ), patch(
            "buoy_search.cli.main.ROUTING_CONFIDENCE_FACTORY",
            return_value=load_collect_routing_confidence_fixture(),
        ), patch(
            "buoy_search.cli.main.ROUTING_EMBEDDER_FACTORY", return_value=FixedEmbedder()
        ):
            result, stdout, stderr = run_cli(
                ["retrieve", "query", "--plan", "--json"],
                env={"TURBOPUFFER_API_KEY": self.API_KEY},
            )
        payload = json.loads(stdout)
        self.assertEqual((result, stderr), (0, ""))
        self.assertEqual(payload["namespaces"], ["eligible"])
        self.assertEqual(payload["routing"]["exclusion_counts"], {"disabled": 1, "stale_target": 1})
        self.assertEqual(
            payload["routing"]["exclusion_ids"],
            {"disabled": ["disabled"], "stale_target": ["stale"]},
        )

    def test_removed_route_top_k_is_rejected_before_provider_work(self) -> None:
        with patch(
            "buoy_search.cli.main.REMOTE_CATALOG_CLIENT_FACTORY",
            side_effect=AssertionError("catalog client constructed"),
        ):
            stdout = StringIO()
            stderr = StringIO()
            with patch.object(
                os, "environ", {"TURBOPUFFER_API_KEY": self.API_KEY}
            ), redirect_stdout(stdout), redirect_stderr(stderr):
                with self.assertRaises(SystemExit) as raised:
                    main(
                        [
                            "retrieve",
                            "query",
                            "--route-top-k",
                            "1",
                            "--plan",
                            "--json",
                        ]
                    )
        self.assertEqual(raised.exception.code, 2)
        self.assertEqual(stdout.getvalue(), "")
        self.assertIn("unrecognized arguments: --route-top-k 1", stderr.getvalue())

    def test_missing_key_fails_before_client_even_if_ambient_namespace_is_set(self) -> None:
        with patch(
            "buoy_search.cli.main.REMOTE_CATALOG_CLIENT_FACTORY",
            side_effect=AssertionError("client constructed"),
        ):
            result, stdout, stderr = run_cli(
                ["retrieve", "query", "--json"],
                env={"TURBOPUFFER_NAMESPACE": "must-be-ignored"},
            )
        self.assertEqual((result, stdout), (2, ""))
        self.assertIn("TURBOPUFFER_API_KEY", stderr)

    def test_explicit_preview_bypasses_credentials_catalog_and_route_model(self) -> None:
        with patch(
            "buoy_search.cli.main.REMOTE_CATALOG_CLIENT_FACTORY",
            side_effect=AssertionError("catalog client constructed"),
        ), patch(
            "buoy_search.cli.main.ROUTING_EMBEDDER_FACTORY",
            side_effect=AssertionError("route model loaded"),
        ), patch(
            "buoy_search.cli.main.load_evidence_calibration",
            side_effect=AssertionError("evidence calibration loaded"),
        ):
            result, stdout, stderr = run_cli(
                [
                    "retrieve",
                    "query",
                    "--namespace",
                    "site-one-v1",
                    "--namespace",
                    "site-two-v1",
                    "--plan",
                    "--json",
                ]
            )
        payload = json.loads(stdout)
        self.assertEqual((result, stderr), (0, ""))
        self.assertEqual(payload["routing"]["mode"], "explicit")
        self.assertFalse(payload["routing"]["active"])
        self.assertFalse(payload["credentials_required"])
        self.assertFalse(payload["turbopuffer_api_calls"])
        self.assertNotIn("evidence", payload)

    def test_explicit_live_single_and_multi_bypass_active_evidence_gate(self) -> None:
        class FakeResult:
            def to_dict(self) -> dict[str, object]:
                return {
                    "command": "retrieve",
                    "dry_run": False,
                    "hits": [],
                }

        class FakeRetriever:
            def retrieve(self, _query, _options, **kwargs):  # noqa: ANN001
                self.assert_no_automatic_kwargs(kwargs)
                return FakeResult()

            @staticmethod
            def assert_no_automatic_kwargs(kwargs: dict[str, object]) -> None:
                if kwargs:
                    raise AssertionError(
                        "explicit retrieval received automatic evidence arguments"
                    )

        with patch(
            "buoy_search.cli.main.load_evidence_calibration",
            side_effect=AssertionError("evidence calibration loaded"),
        ), patch(
            "buoy_search.cli.main.HybridRetriever.from_config",
            return_value=FakeRetriever(),
        ), patch(
            "buoy_search.cli.main.MultiNamespaceRetriever.from_configs",
            return_value=FakeRetriever(),
        ):
            for namespaces in (
                ["site-one-v1"],
                ["site-one-v1", "site-two-v1"],
            ):
                with self.subTest(namespaces=namespaces):
                    args = ["retrieve", "query", "--json"]
                    for namespace in namespaces:
                        args.extend(["--namespace", namespace])
                    result, stdout, stderr = run_cli(args)
                    self.assertEqual((result, stderr), (0, ""))
                    self.assertEqual(json.loads(stdout)["hits"], [])


if __name__ == "__main__":
    unittest.main()
