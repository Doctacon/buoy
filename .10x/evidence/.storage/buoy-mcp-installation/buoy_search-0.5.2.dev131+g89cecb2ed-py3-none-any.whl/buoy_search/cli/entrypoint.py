"""Lightweight dispatch for the legacy CLI and local telemetry commands."""

from __future__ import annotations

from collections.abc import Sequence
import sys
import time


def main(argv: Sequence[str] | None = None) -> int:
    """Dispatch telemetry without importing Buoy's provider-facing CLI."""

    try:
        started_at_ns = time.time_ns()
    except Exception:
        started_at_ns = None
    arguments = list(sys.argv[1:] if argv is None else argv)
    if arguments[:1] == ["mcp"]:
        from buoy_search.mcp import main as mcp_main

        return mcp_main(arguments[1:])
    if arguments[:1] == ["telemetry"]:
        from buoy_search.cli.telemetry import main as telemetry_main

        return telemetry_main(arguments[1:])

    from buoy_search.cli.main import main as legacy_main

    return legacy_main(arguments, entry_started_at_ns=started_at_ns)
